let message = "Hello!";
alert(message);
message = "Whats your name?";
let username = prompt(message);
while (username.length <=0) {
    username = prompt("Please enter a user name that has more than one letter.");
}

if (username.length < 2){
    alert("I see you are using an initial");
}
else{
    alert("Your userName is now updated");
}


function date_of_birth(){
    dob = prompt("Enter your D.O.B.?");
    while (dob.length <=7) {
         dob = prompt("Please enter a valid D.O.B. dd/mm/yy ");
    }
    alert(dob)
}

function showMessage(prompt) {
    alert(prompt);
}